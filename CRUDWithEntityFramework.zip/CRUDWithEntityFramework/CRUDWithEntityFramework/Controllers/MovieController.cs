﻿using CRUDWithEntityFramework.Data;
using CRUDWithEntityFramework.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDWithEntityFramework.Controllers
{
    public class MovieController : Controller
    {
        private readonly ApplicationDbContext dbContext;

        public MovieController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult AddMovies()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> AddMovies(AddStudentViewModel viewModel)
        {
            var movie = new Movie
            {
                Title = viewModel.Title,
                Genre = viewModel.Genre,
                Year = viewModel.Year
            };
            await dbContext.Movies.AddAsync(movie);
            await dbContext.SaveChangesAsync();

            return RedirectToAction("AddMovies");
        }
        [HttpGet]
        public async Task<IActionResult> ListMovies()
        {
            var movies = await dbContext.Movies.ToListAsync();

            return View(movies);
        }
        [HttpGet]
        public async Task<IActionResult> EditMovies(Guid id)
        {
            var movies = await dbContext.Movies.FindAsync(id);

            return View(movies);
        }
        [HttpPost]
        public async Task<IActionResult> EditMovies(Movie viewModel)
        {
            var movies = await dbContext.Movies.FindAsync(viewModel.Id);

            if (movies is not null)
            {
                movies.Title = viewModel.Title;
                movies.Genre = viewModel.Genre;
                movies.Year = viewModel.Year;

                await dbContext.SaveChangesAsync();
            }
            return RedirectToAction("ListMovies", "Movie");
        }
        [HttpGet]
        public async Task<IActionResult> DeleteMovies(Guid id)
        {
            var movies = await dbContext.Movies.FindAsync(id);

            return View(movies);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteMovies(Movie viewModel)
        {
            var movieToDelete = await dbContext.Movies
                .FirstOrDefaultAsync(x => x.Id == viewModel.Id);

            if (movieToDelete != null)
            {
                dbContext.Movies.Remove(movieToDelete);
                await dbContext.SaveChangesAsync();
            }

            return RedirectToAction("ListMovies", "Movie");
        }
    }
}
